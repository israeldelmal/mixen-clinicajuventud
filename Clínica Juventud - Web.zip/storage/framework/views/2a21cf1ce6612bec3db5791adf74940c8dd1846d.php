<?php $__env->startSection('title', 'Escritorio: Servicio -> Servicios'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/servicios')); ?>">Servicios</a></li>
				<li><span>/</span></li>
				<li><strong><?php echo e($service->title); ?>: Servicios</strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($service->title); ?>: Servicios <a href="<?php echo e(url('/escritorio/servicios/servicio/crear/' . $service->id)); ?>"><i class="fas fa-plus"></i> Añadir servicio</a></h1>
			<table>
				<thead>
					<tr>
						<td>Servicio</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Fecha de publicación</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($serviceservices) > 0): ?>
						<?php $__currentLoopData = $serviceservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($serviceservice->name); ?></td>
								<td><?php echo e($serviceservice->user->name); ?> <?php echo e($serviceservice->user->lastname); ?></td>
								<td>
									<?php if($serviceservice->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($serviceservice->created_at->format('d | M | Y')); ?></td>
								<td>
									<a href="<?php echo e(url('/escritorio/servicios/servicio/editar/' . $serviceservice->id)); ?>"><i class="fas fa-pencil-alt"></i> Actualizar</a>
									<a href="<?php echo e(url('/escritorio/servicios/requerimiento/' . $serviceservice->id)); ?>"><i class="far fa-eye"></i> Requerimientos</a>
									<a href="<?php echo e(url('/escritorio/servicios/requerimiento/crear/' . $serviceservice->id)); ?>"><i class="fas fa-plus"></i> Requerimiento</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>