<?php $__env->startSection('title', 'Noticias | Clínica Juventud'); ?>

<?php $__env->startSection('content'); ?>
	<!-- Artículos -->
	<section id="articulos">
		<!-- Noticias -->
		<section id="noticias" style="padding-top: 60px">
			<span class="icon-logo"></span>
			<h1>Mantente Informado</h1>
			<sub style="margin-bottom: 60px;">Contamos con el personal capacitado que aplica el mejor control de calidad 
			en cada uno de nuestros procesos.</sub>
			<main>
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<article>
						<header style="background-image: url('<?php echo e(asset('assets/images/articulos/' . $article->img)); ?>');">
							<time><i class="far fa-clock"></i> <?php echo e($article->created_at->format('d | M | Y')); ?></time>
						</header>
						<h1><?php echo e($article->title); ?></h1>
						<p><?php echo strip_tags(trim(substr($article->content, 0, 220))); ?>...</p>
						<a href="<?php echo e(url('/noticias/' . $article->slug)); ?>">Leer más</a>
					</article>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</main>
			<?php echo e($articles->links()); ?>

		</section>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>