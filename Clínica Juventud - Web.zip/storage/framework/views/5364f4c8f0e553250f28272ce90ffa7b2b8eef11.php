<?php $__env->startSection('title', 'Escritorio: Descanso #1'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Editar Descanso #1</h1>
			<form action="<?php echo e(url('/escritorio/descanso-1/actualizar/' . $break->id)); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="h1">Título</label>
					<textarea name="h1" id="h1" rows="5" placeholder="Título del descanso"><?php echo e($break->h1); ?></textarea>
					<?php if($errors->has('h1')): ?>
						<div><?php echo e($errors->first('h1')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="img">Imagen de Fondo</label>
					<input type="file" name="img" id="img">
					<?php if($errors->has('img')): ?>
						<div><?php echo e($errors->first('img')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>