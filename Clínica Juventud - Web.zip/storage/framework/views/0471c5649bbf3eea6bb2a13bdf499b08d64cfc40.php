<?php $__env->startSection('title', 'Escritorio'); ?>

<?php $__env->startSection('content'); ?>
	<div id="index">
		<ul>
			<li>
				<span>Artículos</span>
				<span><?php echo e(count($count_articles)); ?></span>
			</li>
			<li>
				<span>Paquetes</span>
				<span><?php echo e(count($count_packs)); ?></span>
			</li>
			<li>
				<span>Servicios</span>
				<span><?php echo e(count($count_services)); ?></span>
			</li>
			<li>
				<span>Usuarios</span>
				<span><?php echo e(count($count_users)); ?></span>
			</li>
		</ul>
		<div>
			<h1>Últimos artículos</h1>
			<table>
				<thead>
					<tr>
						<td>Artículo</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Fecha</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($articles) > 0): ?>
						<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($article->title); ?></td>
								<td><?php echo e($article->user->name); ?> <?php echo e($article->user->lastname); ?></td>
								<td>
									<?php if($article->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($article->created_at->format('d | M | Y')); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<div>
			<h1>Paquetes activos</h1>
			<table>
				<thead>
					<tr>
						<td>Paquete</td>
						<td>Autor</td>
						<td>Fecha</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($packs) > 0): ?>
						<?php $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($pack->title); ?></td>
								<td><?php echo e($pack->user->name); ?> <?php echo e($pack->user->lastname); ?></td>
								<td><?php echo e($pack->created_at->format('d | M | Y')); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<div>
			<h1>Servicios activos</h1>
			<table>
				<thead>
					<tr>
						<td>Servicio</td>
						<td>Autor</td>
						<td>Fecha</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($services) > 0): ?>
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($service->title); ?></td>
								<td><?php echo e($service->user->name); ?> <?php echo e($service->user->lastname); ?></td>
								<td><?php echo e($service->created_at->format('d | M | Y')); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>