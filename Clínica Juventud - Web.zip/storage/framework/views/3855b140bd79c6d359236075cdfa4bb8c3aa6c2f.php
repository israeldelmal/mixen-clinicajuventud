<?php $__env->startSection('title', 'Escritorio: Paquetes -> Editar servicio'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/paquetes')); ?>">Paquetes</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/paquetes/servicio/' . $packservice->pack->id)); ?>"><?php echo e($packservice->pack->title); ?>: Servicios</a></li>
				<li><span>/</span></li>
				<li><strong>Editar: <?php echo e($packservice->name); ?></strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($packservice->pack->title); ?> / Actualizar servicio: <?php echo e($packservice->name); ?></h1>
			<form action="<?php echo e(url('/escritorio/paquetes/servicio/actualizar/' . $packservice->id)); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="name">Nombre</label>
					<input type="text" name="name" id="name" placeholder="Nombre del servicio" autocomplete="off" autofocus value="<?php echo e($packservice->name); ?>">
					<?php if($errors->has('name')): ?>
						<div><?php echo e($errors->first('name')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="pack_id">Paquete</label>
					<select name="pack_id" id="pack_id">
						<option value="<?php echo e($packservice->pack->id); ?>"><?php echo e($packservice->pack->title); ?></option>
						<?php $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($pack->id); ?>"><?php echo e($pack->title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div>
					<label for="status">Estatus</label>
					<select name="status" id="status">
						<option value="1">Activo</option>
						<option value="0" <?php if($packservice->status == false): ?> selected <?php endif; ?>>Inactivo</option>
					</select>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>