<?php $__env->startSection('title'); ?>
	Escritorio: <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Actualizar información</h1>
			<form action="<?php echo e(url('/escritorio/usuario/actualizar/' . Auth::user()->id)); ?>" method="POST">
				<div>
					<label for="name">Nombre</label>
					<input type="text" name="name" id="name" placeholder="Nombre" autocomplete="off" autofocus value="<?php echo e(Auth::user()->name); ?>">
					<?php if($errors->has('name')): ?>
						<div><?php echo e($errors->first('name')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="lastname">Apellido</label>
					<input type="text" name="lastname" id="lastname" placeholder="Apellido" autocomplete="off" autofocus value="<?php echo e(Auth::user()->lastname); ?>">
					<?php if($errors->has('lastname')): ?>
						<div><?php echo e($errors->first('lastname')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>