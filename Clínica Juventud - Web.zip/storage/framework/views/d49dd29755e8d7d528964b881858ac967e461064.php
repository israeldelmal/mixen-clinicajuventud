<?php $__env->startSection('title', 'Escritorio: Artículos'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Listado de Artículos</h1>
			<table>
				<thead>
					<tr>
						<td>Título</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Decha de publicación</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($articles) > 0): ?>
						<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($article->title); ?></td>
								<td><?php echo e($article->user->name); ?> <?php echo e($article->user->lastname); ?></td>
								<td>
									<?php if($article->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($article->created_at->format('d | M | Y')); ?></td>
								<td>
									<a href="<?php echo e(url('/escritorio/articulos/editar/' . $article->id)); ?>"><i class="fas fa-pencil-alt"></i> Editar</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>