<?php $__env->startSection('title', 'Escritorio: Crear Servicio'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Crear Servicio</h1>
			<form action="<?php echo e(url('/escritorio/servicios/almacenar')); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="title">Título</label>
					<input type="text" name="title" id="title" placeholder="Título del servicio" autocomplete="off" autofocus value="<?php echo e(old('title')); ?>">
					<?php if($errors->has('title')): ?>
						<div><?php echo e($errors->first('title')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="subtitle">Subtítulo</label>
					<input type="text" name="subtitle" id="subtitle" placeholder="Subtítulo del servicio" autocomplete="off" autofocus value="<?php echo e(old('subtitle')); ?>">
					<?php if($errors->has('subtitle')): ?>
						<div><?php echo e($errors->first('subtitle')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="img">Imagen del Servicio</label>
					<input type="file" name="img" id="img">
					<?php if($errors->has('img')): ?>
						<div><?php echo e($errors->first('img')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="cover">Portada del Servicio</label>
					<input type="file" name="cover" id="cover">
					<?php if($errors->has('cover')): ?>
						<div><?php echo e($errors->first('cover')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Crear</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>