<?php $__env->startSection('title', 'Escritorio: Crear artículo'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Crear artículo</h1>
			<form action="<?php echo e(url('/escritorio/articulos/almacenar')); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="title">Título</label>
					<input type="text" name="title" id="title" placeholder="Título del artículo" autocomplete="off" autofocus value="<?php echo e(old('title')); ?>">
					<?php if($errors->has('title')): ?>
						<div><?php echo e($errors->first('title')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="img">Imagen</label>
					<input type="file" name="img" id="img">
					<?php if($errors->has('img')): ?>
						<div><?php echo e($errors->first('img')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="content">Contenido</label>
					<textarea name="content" id="formcontent"><?php echo e(old('content')); ?></textarea>
					<?php if($errors->has('content')): ?>
						<div><?php echo e($errors->first('content')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Crear</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src="//cdn.ckeditor.com/4.10.0/standard/ckeditor.js"></script>
	<script>
		CKEDITOR.replace( 'formcontent' );
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>