<?php $__env->startSection('title', 'Error 404'); ?>

<?php $__env->startSection('h1', 'No se encontró la página, serás redirigido'); ?>
<?php echo $__env->make('errors.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>