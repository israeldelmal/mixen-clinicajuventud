<?php $__env->startSection('title'); ?>
	Servicio: <?php echo e($service->title); ?> | Clínica Juventud
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Servicio -->
	<section id="servicio">
		<header data-parallax="scroll" data-image-src="<?php echo e(asset('assets/images/servicio/fondo.jpg')); ?>">
			<h1>Calidad en la atención
			<strong>de tu salud</strong></h1>
		</header>
		<nav>
			<h2>Conoce nuestros Servicios</h2>
			<ul>
				<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($servicio->id == $service->id): ?>
						<li><a class="active" href="<?php echo e(url('/servicios/'. $servicio->slug)); ?>">
							<img src="<?php echo e(asset('assets/images/servicios/' . $servicio->img)); ?>">
							<i><?php echo e($servicio->title); ?></i>
						</a></li>
					<?php else: ?>
						<li><a href="<?php echo e(url('/servicios/'. $servicio->slug)); ?>">
							<img src="<?php echo e(asset('assets/images/servicios/' . $servicio->img)); ?>">
							<i><?php echo e($servicio->title); ?></i>
						</a></li>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</nav>
		<section>
			<?php if(count($service->serviceservices) > 0): ?>
				<h3><?php echo e($service->title); ?></h3>
				<sub><?php echo e($service->subtitle); ?></sub>
				<div>
					<aside style="height: 700px; overflow-y: auto;">
						<ul>
							<?php $__currentLoopData = $ser_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="item-service">
									<a href="#"><?php echo e($serv->name); ?></a>
									<ul>
										<?php $__currentLoopData = $req_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($req->serviceservice->id == $serv->id): ?>
												<li><?php echo e($req->name); ?></li>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</aside>
					<section>
						<img src="<?php echo e(asset('assets/images/servicios/' . $service->cover)); ?>">
					</section>
				</div>
			<?php else: ?>
				<h3><?php echo e($service->title); ?></h3>
				<div style="background-image: url('<?php echo e(asset('assets/images/servicios/' . $service->cover)); ?>');">
					<div>
						<p><?php echo e($service->subtitle); ?></p>
					</div>
				</div>
			<?php endif; ?>
		</section>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('assets/js/parallax.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>