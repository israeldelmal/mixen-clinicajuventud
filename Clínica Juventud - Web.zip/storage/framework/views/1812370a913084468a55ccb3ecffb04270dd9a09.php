<?php $__env->startSection('title', 'Escritorio: Paquete -> Servicios -> Editar requerimiento'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/paquetes')); ?>">Paquetes</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/paquetes/servicio/' . $requirement->packservice->pack->id)); ?>"><?php echo e($requirement->packservice->pack->title); ?>: Servicios</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/paquetes/requerimiento/' . $requirement->packservice->id)); ?>"><?php echo e($requirement->packservice->name); ?>: Requerimiento</a></li>
				<li><span>/</span></li>
				<li><strong>Editar Requerimiento</strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($requirement->packservice->name); ?>: Editar requerimiento</h1>
			<form action="<?php echo e(url('/escritorio/paquetes/requerimiento/actualizar/' . $requirement->id)); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="name">Nombre</label>
					<input type="text" name="name" id="name" placeholder="Nombre del requerimiento" autocomplete="off" autofocus value="<?php echo e($requirement->name); ?>">
					<?php if($errors->has('name')): ?>
						<div><?php echo e($errors->first('name')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="packservice_id">Servicio</label>
					<select name="packservice_id" id="packservice_id">
						<option value="<?php echo e($requirement->packservice->id); ?>"><?php echo e($requirement->packservice->name); ?></option>
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php if($errors->has('packservice_id')): ?>
						<div><?php echo e($errors->first('packservice_id')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="status">Estatus</label>
					<select name="status" id="status">
						<option value="1">Activo</option>
						<option value="0" <?php if($requirement->status == false): ?> selected <?php endif; ?>>Inactivo</option>
					</select>
					<?php if($errors->has('status')): ?>
						<div><?php echo e($errors->first('status')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>