<?php $__env->startSection('title', 'Escritorio: Cabeceras'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Editar Cabecera</h1>
			<form action="<?php echo e(url('/escritorio/cabeceras/actualizar/' . $header->id)); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="h1">Título</label>
					<textarea name="h1" id="h1" rows="5" placeholder="Título del servicio"><?php echo e($header->h1); ?></textarea>
					<?php if($errors->has('h1')): ?>
						<div><?php echo e($errors->first('h1')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="sub">Subtítulo</label>
					<textarea name="sub" id="sub" rows="5" placeholder="Subtítulo del servicio"><?php echo e($header->sub); ?></textarea>
					<?php if($errors->has('sub')): ?>
						<div><?php echo e($errors->first('sub')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="img">Imagen de Fondo</label>
					<input type="file" name="img" id="img">
					<?php if($errors->has('img')): ?>
						<div><?php echo e($errors->first('img')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>