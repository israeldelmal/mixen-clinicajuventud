<?php $__env->startSection('title', 'Escritorio: Servicios -> Editar servicio'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/servicios')); ?>">Servicios</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/servicios/servicio/' . $serviceservice->service->id)); ?>"><?php echo e($serviceservice->service->title); ?>: Servicios</a></li>
				<li><span>/</span></li>
				<li><strong>Editar: <?php echo e($serviceservice->name); ?></strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($serviceservice->service->title); ?> / Actualizar servicio: <?php echo e($serviceservice->name); ?></h1>
			<form action="<?php echo e(url('/escritorio/servicios/servicio/actualizar/' . $serviceservice->id)); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="name">Nombre</label>
					<input type="text" name="name" id="name" placeholder="Nombre del servicio" autocomplete="off" autofocus value="<?php echo e($serviceservice->name); ?>">
					<?php if($errors->has('name')): ?>
						<div><?php echo e($errors->first('name')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="service_id">Paquete</label>
					<select name="service_id" id="service_id">
						<option value="<?php echo e($serviceservice->service->id); ?>"><?php echo e($serviceservice->service->title); ?></option>
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($service->id); ?>"><?php echo e($service->title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div>
					<label for="status">Estatus</label>
					<select name="status" id="status">
						<option value="1">Activo</option>
						<option value="0" <?php if($serviceservice->status == false): ?> selected <?php endif; ?>>Inactivo</option>
					</select>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>