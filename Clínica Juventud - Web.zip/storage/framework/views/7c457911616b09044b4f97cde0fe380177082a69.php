<?php $__env->startSection('title', 'Escritorio: Usuarios'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Listado de Usuarios</h1>
			<table>
				<thead>
					<tr>
						<td>Nombre</td>
						<td>E-mail</td>
						<td>Estatus</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td>
								<?php if($user->status == true): ?>
									Activo
								<?php else: ?>
									Inactivo
								<?php endif; ?>
							</td>
							<td>
								<a href="<?php echo e(url('/escritorio/usuarios/editar/' . $user->id)); ?>"><i class="fas fa-pencil-alt"></i> Editar</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>