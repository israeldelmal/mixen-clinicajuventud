<?php $__env->startSection('title'); ?>
	Paquete: <?php echo e($pack->title); ?> | Clínica Juventud
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Paquetes -->
	<section id="paquetes" style="padding: 0px !important; padding-top: 80px !important; margin-top: 130px !important;">
		<span class="icon-logo"></span>
		<h1>Aprovecha nuestros Paquetes</h1>
		<sub>Contamos con el personal capacitado que aplica el mejor control de calidad 
		en cada uno de nuestros procesos.</sub>
		<section>
			<?php $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($paquete->id == $pack->id): ?>
					<div class="active-pack" style="background-image: url('<?php echo e(asset('assets/images/paquetes/' . $paquete->img)); ?>');">
						<a href="<?php echo e(url('/paquetes/' . $paquete->slug)); ?>">
							<h2><?php echo e($paquete->title); ?></h2>
						</a>
					</div>
				<?php else: ?>
					<div style="background-image: url('<?php echo e(asset('assets/images/paquetes/' . $paquete->img)); ?>');">
						<a href="<?php echo e(url('/paquetes/' . $paquete->slug)); ?>">
							<h2><?php echo e($paquete->title); ?></h2>
						</a>
					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</section>
	</section>
	<!-- Servicio -->
	<section id="servicio">
		<section>
			<div>
				<aside>
					<?php if(count($ser_packs) > 0): ?>
						<ul>
							<?php $__currentLoopData = $ser_packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="item-service">
									<a href="#"><?php echo e($paquete->name); ?></a>
									<ul>
										<?php $__currentLoopData = $req_packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($req->packservice->id == $paquete->id): ?>
												<li><?php echo e($req->name); ?></li>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					<?php else: ?>
						<ul>
							<li class="item-service">
								<a href="#">Próximamente</a>
								<ul>
									<li>#</li>
									<li>#</li>
									<li>#</li>
									<li>#</li>
									<li>#</li>
								</ul>
							</li>
						</ul>
					<?php endif; ?>
				</aside>
				<section>
					<img src="<?php echo e(asset('assets/images/paquetes/' . $pack->cover)); ?>">
				</section>
			</div>
		</section>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('assets/js/parallax.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>