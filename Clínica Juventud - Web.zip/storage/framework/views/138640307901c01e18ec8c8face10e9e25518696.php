<?php $__env->startSection('title', 'Escritorio: Paquete -> Servicios -> Editar requerimiento'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/servicios')); ?>">Servicios</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/servicios/servicio/' . $requirement->serviceservice->service->id)); ?>"><?php echo e($requirement->serviceservice->service->title); ?>: Servicios</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/servicios/requerimiento/' . $requirement->serviceservice->id)); ?>"><?php echo e($requirement->serviceservice->name); ?>: Requerimiento</a></li>
				<li><span>/</span></li>
				<li><strong>Editar Requerimiento</strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($requirement->serviceservice->name); ?>: Editar requerimiento</h1>
			<form action="<?php echo e(url('/escritorio/servicios/requerimiento/actualizar/' . $requirement->id)); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="name">Nombre</label>
					<input type="text" name="name" id="name" placeholder="Nombre del requerimiento" autocomplete="off" autofocus value="<?php echo e($requirement->name); ?>">
					<?php if($errors->has('name')): ?>
						<div><?php echo e($errors->first('name')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="serviceservice_id">Servicio</label>
					<select name="serviceservice_id" id="serviceservice_id">
						<option value="<?php echo e($requirement->serviceservice->id); ?>"><?php echo e($requirement->serviceservice->name); ?></option>
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php if($errors->has('serviceservice_id')): ?>
						<div><?php echo e($errors->first('serviceservice_id')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<label for="status">Estatus</label>
					<select name="status" id="status">
						<option value="1">Activo</option>
						<option value="0" <?php if($requirement->status == false): ?> selected <?php endif; ?>>Inactivo</option>
					</select>
					<?php if($errors->has('status')): ?>
						<div><?php echo e($errors->first('status')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>