<?php $__env->startSection('title', 'Escritorio: Paquetes'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Listado de Paquetes</h1>
			<table>
				<thead>
					<tr>
						<td>Nombre</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Fecha de publicación</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($packs) > 0): ?>
						<?php $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($pack->title); ?></td>
								<td><?php echo e($pack->user->name); ?> <?php echo e($pack->user->lastname); ?></td>
								<td>
									<?php if($pack->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($pack->created_at->format('d | M | Y')); ?></td>
								<td>
									<a href="<?php echo e(url('/escritorio/paquetes/editar/' . $pack->id)); ?>"><i class="fas fa-pencil-alt"></i> Editar</a>
									<a href="<?php echo e(url('/escritorio/paquetes/servicio/' . $pack->id)); ?>"><i class="far fa-eye"></i> Servicios</a>
									<a href="<?php echo e(url('/escritorio/paquetes/servicio/crear/' . $pack->id)); ?>"><i class="fas fa-plus"></i> Servicio</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>