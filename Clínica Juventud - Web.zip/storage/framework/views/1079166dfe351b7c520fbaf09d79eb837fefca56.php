<?php $__env->startSection('title', 'Escritorio: Servicio -> Servicios -> Añadir requerimiento'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/servicios')); ?>">Servicios</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/servicios/servicio/' . $service->service->id)); ?>"><?php echo e($service->service->title); ?>: Servicios</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/servicios/requerimiento/' . $service->id)); ?>"><?php echo e($service->name); ?>: Requerimiento</a></li>
				<li><span>/</span></li>
				<li><strong>Añadir Requerimiento</strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($service->name); ?>: Añadir requerimiento</h1>
			<form action="<?php echo e(url('/escritorio/servicios/requerimiento/almacenar')); ?>" method="POST" enctype="multipart/form-data">
				<div>
					<label for="name">Nombre</label>
					<input type="text" name="name" id="name" placeholder="Nombre del requerimiento" autocomplete="off" autofocus value="<?php echo e(old('name')); ?>">
					<?php if($errors->has('name')): ?>
						<div><?php echo e($errors->first('name')); ?></div>
					<?php endif; ?>
				</div>
				<div>
					<button type="submit">Crear</button>
				</div>
				<input type="hidden" name="serviceservice_id" id="serviceservice_id" value="<?php echo e($service->id); ?>">
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>