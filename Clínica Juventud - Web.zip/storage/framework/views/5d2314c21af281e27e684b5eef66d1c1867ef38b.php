<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/icon.png')); ?>">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/dashboard.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/icons/style.css')); ?>">
</head>
<body>
	
	<nav>
		<div>
			<a href="#">
				<?php if(empty(Auth::user()->profile->image)): ?>
					<img src="<?php echo e(asset('assets/images/escritorio/user.jpg')); ?>">
				<?php else: ?>
					<img src="<?php echo e(asset('assets/images/escritorio/users/' . $user->slug . '/' . $user->profile->image)); ?>">
				<?php endif; ?>
				<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?>

			</a>
			<a href="<?php echo e(url('/escritorio')); ?>"><i class="fas fa-tachometer-alt"></i></a>
			<a href="<?php echo e(url('/autenticacion/cerrar-sesion')); ?>"><i class="fas fa-power-off"></i></a>
		</div>
	</nav>
	
	<aside>
		<div>
			<img src="<?php echo e(asset('assets/images/logo.png')); ?>">
			<h1>Escritorio</h1>
		</div>
		<ul>
			<li>
				<a href="#"
					<?php if(Route::is('escritorio/usuarios')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/editar')): ?> class="active" <?php endif; ?>
				><span class="icon-Users"></span> Usuarios</a>
				<ul
					<?php if(Route::is('escritorio/usuarios')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/editar')): ?> class="show" <?php endif; ?>
				>
					<li><a
						<?php if(Route::is('escritorio/usuarios')): ?> class="active" <?php endif; ?>
						<?php if(Route::is('escritorio/editar')): ?> class="active" <?php endif; ?>
						href="<?php echo e(url('/escritorio/usuarios')); ?>"><span class="icon-List"></span> Lista</a></li>
				</ul>
			</li>
			<li>
				<a href="#"
					<?php if(Route::is('escritorio/cabeceras')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/descanso-1')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/descanso-2')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/descanso-3')): ?> class="active" <?php endif; ?>
				><span class="icon-Home"></span> Inicio</a>
				<ul
					<?php if(Route::is('escritorio/cabeceras')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/descanso-1')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/descanso-2')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/descanso-3')): ?> class="show" <?php endif; ?>
				>
					<li><a <?php if(Route::is('escritorio/cabeceras')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/cabeceras/1')); ?>"><span class="icon-Edit"></span> Cabecera</a></li>
					<li><a <?php if(Route::is('escritorio/descanso-1')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/descanso-1/1')); ?>"><span class="icon-Edit"></span> Descanso #1</a></li>
					<li><a <?php if(Route::is('escritorio/descanso-2')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/descanso-2/1')); ?>"><span class="icon-Edit"></span> Descanso #2</a></li>
					<li><a <?php if(Route::is('escritorio/descanso-3')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/descanso-3/1')); ?>"><span class="icon-Edit"></span> Descanso #3</a></li>
				</ul>
			</li>
			<li>
				<a href="#"
					<?php if(Route::is('escritorio/articulos')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/articulos/crear')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/articulos/editar')): ?> class="active" <?php endif; ?>
				><span class="icon-Articles"></span> Blog</a>
				<ul
					<?php if(Route::is('escritorio/articulos')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/articulos/crear')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/articulos/editar')): ?> class="show" <?php endif; ?>
				>
					<li><a <?php if(Route::is('escritorio/articulos')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/articulos')); ?>"><span class="icon-List"></span> Lista</a></li>
					<li><a <?php if(Route::is('escritorio/articulos/crear')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/articulos/crear')); ?>"><span class="icon-Add"></span> Añadir</a></li>
				</ul>
			</li>
			<li>
				<a href="#"
					<?php if(Route::is('escritorio/servicios')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/servicios/crear')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/servicios/servicios')): ?> class="active" <?php endif; ?>
				><span class="icon-Services"></span> Servicios</a>
				<ul
					<?php if(Route::is('escritorio/servicios')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/servicios/crear')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/servicios/servicios')): ?> class="show" <?php endif; ?>
				>
					<li><a <?php if(Route::is('escritorio/servicios')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/servicios')); ?>"><span class="icon-List"></span> Lista</a></li>
					<li><a <?php if(Route::is('escritorio/servicios/crear')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/servicios/crear')); ?>"><span class="icon-Add"></span> Añadir</a></li>
				</ul>
			</li>
			<li>
				<a href="#"
					<?php if(Route::is('escritorio/paquetes')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/paquetes/crear')): ?> class="active" <?php endif; ?>
					<?php if(Route::is('escritorio/paquetes/servicios')): ?> class="active" <?php endif; ?>
				><span class="icon-Packages"></span> Paquetes</a>
				<ul
					<?php if(Route::is('escritorio/paquetes')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/paquetes/crear')): ?> class="show" <?php endif; ?>
					<?php if(Route::is('escritorio/paquetes/servicios')): ?> class="show" <?php endif; ?>
				>
					<li><a <?php if(Route::is('escritorio/paquetes')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/paquetes')); ?>"><span class="icon-List"></span> Lista</a></li>
					<li><a <?php if(Route::is('escritorio/paquetes/crear')): ?> class="active" <?php endif; ?> href="<?php echo e(url('/escritorio/paquetes/crear')); ?>"><span class="icon-Add"></span> Añadir</a></li>
				</ul>
			</li>
		</ul>
	</aside>
	
	<section>
		<?php echo $__env->yieldContent('content'); ?>
	</section>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
	<?php echo $__env->yieldContent('js'); ?>
</body>
</html>