<?php $__env->startSection('title'); ?>
	Noticias: <?php echo e($article->title); ?> | Clínica Juventud
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Artículo -->
	<section id="articulo">
		<div>
			<article>
				<h1><?php echo e($article->title); ?></h1>
				<?php echo $article->content; ?>

			</article>
		</div>
		<div style="background-image: url(<?php echo e(asset('assets/images/articulos/' . $article->img)); ?>);"></div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<!-- JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>