<?php $__env->startSection('title', 'Escritorio: Servicios'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Listado de Servicios</h1>
			<table>
				<thead>
					<tr>
						<td>Nombre</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Fecha de publicación</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($services) > 0): ?>
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($service->title); ?></td>
								<td><?php echo e($service->user->name); ?> <?php echo e($service->user->lastname); ?></td>
								<td>
									<?php if($service->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($service->created_at->format('d | M | Y')); ?></td>
								<td>
									<a href="<?php echo e(url('/escritorio/servicios/editar/' . $service->id)); ?>"><i class="fas fa-pencil-alt"></i> Editar</a>
									<a href="<?php echo e(url('/escritorio/servicios/servicio/' . $service->id)); ?>"><i class="far fa-eye"></i> Servicios</a>
									<a href="<?php echo e(url('/escritorio/servicios/servicio/crear/' . $service->id)); ?>"><i class="fas fa-plus"></i> Servicio</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>