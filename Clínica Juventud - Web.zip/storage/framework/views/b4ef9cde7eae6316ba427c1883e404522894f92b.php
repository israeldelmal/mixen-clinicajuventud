<?php $__env->startSection('title', 'Escritorio: Editar usuario'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<div>
			<h1>Editar usuario: <?php echo e($user->name); ?> <?php echo e($user->lastname); ?></h1>
			<form action="<?php echo e(url('/escritorio/usuarios/actualizar/' . $user->id)); ?>" method="POST">
				<div>
					<label for="status">Estatus</label>
					<select name="status" id="status">
						<option value="1">Activo</option>
						<option <?php if($user->status == false): ?> selected <?php endif; ?> value="0">Inactivo</option>
					</select>
				</div>
				<div>
					<button type="submit">Actualizar</button>
				</div>
				<?php echo e(csrf_field()); ?>

			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>