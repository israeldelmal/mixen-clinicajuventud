<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="author" content="Mixen: Boosting Brands">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo $__env->yieldContent('title'); ?> | Clínica Juventud</title>
	<link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/icon.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/errors.css')); ?>">
</head>
<body>
	<section id="errors">
		<div>
			<h1><?php echo $__env->yieldContent('h1'); ?></h1>
		</div>
		<div style="background-image: url('<?php echo e(asset('assets/images/servicio/fondo.jpg')); ?>');"></div>
	</section>
	<script>
		function redireccionarPagina() {
			window.location.href = "<?php echo e(url('/')); ?>";
		}

		setTimeout("redireccionarPagina()", 5000);
	</script>
</body>
</html>