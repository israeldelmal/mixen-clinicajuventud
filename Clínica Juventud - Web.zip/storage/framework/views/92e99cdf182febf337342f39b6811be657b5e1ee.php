<?php $__env->startSection('title', 'Escritorio: Paquete -> Servicios'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/paquetes')); ?>">Paquetes</a></li>
				<li><span>/</span></li>
				<li><strong><?php echo e($pack->title); ?>: Servicios</strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($pack->title); ?>: Servicios <a href="<?php echo e(url('/escritorio/paquetes/servicio/crear/' . $pack->id)); ?>"><i class="fas fa-plus"></i> Añadir servicio</a></h1>
			<table>
				<thead>
					<tr>
						<td>Servicio</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Fecha de publicación</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($packservices) > 0): ?>
						<?php $__currentLoopData = $packservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($packservice->name); ?></td>
								<td><?php echo e($packservice->user->name); ?> <?php echo e($packservice->user->lastname); ?></td>
								<td>
									<?php if($packservice->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($packservice->created_at->format('d | M | Y')); ?></td>
								<td>
									<a href="<?php echo e(url('/escritorio/paquetes/servicio/editar/' . $packservice->id)); ?>"><i class="fas fa-pencil-alt"></i> Actualizar</a>
									<a href="<?php echo e(url('/escritorio/paquetes/requerimiento/' . $packservice->id)); ?>"><i class="far fa-eye"></i> Requerimientos</a>
									<a href="<?php echo e(url('/escritorio/paquetes/requerimiento/crear/' . $packservice->id)); ?>"><i class="fas fa-plus"></i> Requerimiento</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>