<?php $__env->startSection('title', 'Escritorio: Paquete -> Servicios -> Requerimientos'); ?>

<?php $__env->startSection('content'); ?>
	<div class="forms">
		<nav>
			<ul>
				<li><a href="<?php echo e(url('/escritorio/paquetes')); ?>">Paquetes</a></li>
				<li><span>/</span></li>
				<li><a href="<?php echo e(url('/escritorio/paquetes/servicio/' . $service->pack->id)); ?>"><?php echo e($service->pack->title); ?>: Servicios</a></li>
				<li><span>/</span></li>
				<li><strong><?php echo e($service->pack->title); ?>: Requerimientos</strong></li>
			</ul>
		</nav>
		<div>
			<h1><?php echo e($service->pack->title); ?>: Servicios > Requerimientos <a href="<?php echo e(url('/escritorio/paquetes/requerimiento/crear/' . $service->id)); ?>"><i class="fas fa-plus"></i> Añadir requerimiento</a></h1>
			<table>
				<thead>
					<tr>
						<td>Requerimiento</td>
						<td>Autor</td>
						<td>Estatus</td>
						<td>Fecha de publicación</td>
						<td>Acciones</td>
					</tr>
				</thead>
				<tbody>
					<?php if(count($requirements) > 0): ?>
						<?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($requirement->name); ?></td>
								<td><?php echo e($requirement->user->name); ?> <?php echo e($requirement->user->lastname); ?></td>
								<td>
									<?php if($requirement->status == true): ?>
										Activo
									<?php else: ?>
										Inactivo
									<?php endif; ?>
								</td>
								<td><?php echo e($requirement->created_at->format('d | M | Y')); ?></td>
								<td>
									<a href="<?php echo e(url('/escritorio/paquetes/requerimiento/editar/' . $requirement->id)); ?>"><i class="fas fa-pencil-alt"></i> Actualizar</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td>Próximamente</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
							<td>#</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>