<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Break2 extends Model
{
    protected $table = '2breaks';

    protected $fillable = [
    	'h1', 'img'
	];
}
