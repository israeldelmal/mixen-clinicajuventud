<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Break3 extends Model
{
    protected $table = '3breaks';

    protected $fillable = [
    	'h1', 'img'
	];
}
