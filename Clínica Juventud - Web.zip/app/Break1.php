<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Break1 extends Model
{
    protected $table = '1breaks';

    protected $fillable = [
    	'h1', 'img'
	];
}
