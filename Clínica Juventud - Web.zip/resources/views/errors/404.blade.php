@extends('errors.master')

@section('title', 'Error 404')

@section('h1', 'No se encontró la página, serás redirigido')