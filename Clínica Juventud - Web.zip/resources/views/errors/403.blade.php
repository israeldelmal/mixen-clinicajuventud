@extends('errors.master')

@section('title', 'Error 404')

@section('h1', 'No tienes permisos para eacceder a esta página, serás redirigido')